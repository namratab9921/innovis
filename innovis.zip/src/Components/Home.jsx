import React from 'react'
import sampleimage1 from '../Images/sampleimage1.png'
import sampleimage2 from '../Images/sampleimage2.png'

export default function Home() {
  // document.getElementById('box5').addEventListener('click', function () {
  //   window.location.href = '3D_Viewer/3D_Model.html';
  // });

  // // Carousel functionality
  // let currentIndex = 0;
  // const images = document.querySelectorAll('.carousel-inner img');
  // const totalImages = images.length;

  // function moveCarousel(direction) {
  //   currentIndex = (currentIndex + direction + totalImages) % totalImages;
  //   const offset = -currentIndex * 100;
  //   document.querySelector('.carousel-inner').style.transform = `translateX(${offset}%)`;
  // }

  // // Basic setup for 3D scene
  // const scene = new THREE.Scene();
  // const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.01, 1000);
  // const renderer = new THREE.WebGLRenderer({ antialias: true });
  // renderer.setSize(window.innerWidth, window.innerHeight);
  // const modelDiv = document.getElementById('box5');
  // modelDiv.appendChild(renderer.domElement);

  // const updateRendererSize = () => {
  //   const width = modelDiv.clientWidth;
  //   const height = modelDiv.clientHeight;
  //   renderer.setSize(width, height);
  //   camera.aspect = width / height;
  //   camera.updateProjectionMatrix();
  // };
  // updateRendererSize();
  // window.addEventListener('resize', updateRendererSize);

  // const ambientLight = new THREE.AmbientLight(0xffffff, 1);
  // scene.add(ambientLight);
  // const pointLight = new THREE.PointLight(0xffffff, 1, 100);
  // pointLight.position.set(10, 10, 10);
  // scene.add(pointLight);

  // const mtlLoader = new THREE.MTLLoader();
  // mtlLoader.load(
  //   '3D_small/Model.mtl',
  //   function (materials) {
  //     materials.preload();
  //     const objLoader = new THREE.OBJLoader();
  //     objLoader.setMaterials(materials);
  //     objLoader.load(
  //       '3D_small/Model_center.obj',
  //       function (object) {
  //         object.scale.set(0.20, 0.20, 0.20);
  //         object.rotation.x = 3 * Math.PI / 2;
  //         scene.add(object);
  //         object.position.y = 0.3;
  //       },
  //       function (xhr) {
  //         console.log((xhr.loaded / xhr.total * 100) + '% loaded');
  //       },
  //       function (error) {
  //         console.log('An error happened:', error);
  //       }
  //     );
  //   },
  //   function (xhr) {
  //     console.log((xhr.loaded / xhr.total * 100) + '% loaded');
  //   },
  //   function (error) {
  //     console.log('An error happened:', error);
  //   }
  // );

  // camera.position.z = 5;

  // let rotationSpeed = 0.01;
  // let rotationAxis = new THREE.Vector3(0, 0, 1);

  // function animate() {
  //   requestAnimationFrame(animate);
  //   scene.traverse(function (child) {
  //     if (child.isMesh) {
  //       child.rotateOnAxis(rotationAxis, rotationSpeed);
  //     }
  //   });
  //   renderer.render(scene, camera);
  // }
  // animate();


  return (
    <div>
      <div className="search-area">
        <input id="search-input" type="text" placeholder="Search by Name, location..." />
        <select id="site-type">
          <option value="">Choose Site Type</option>
          <option value="GBT">GBT (Ground Based Tower)</option>
          <option value="RTT">RTT (Roof Top Tower)</option>
          <option value="RI">RI (Roof Installation)</option>
        </select>
        <select id="category">
          <option value="">Choose Category</option>
          <option value="Platinum">Platinum</option>
          <option value="Gold">Gold</option>
          <option value="Silver">Silver</option>
        </select>
        <select id="maint-status">
          <option value="">Choose Maint. Status</option>
          <option value="completed_last_month">Completed &lt; 1 Month Ago</option>
          <option value="completed_last_year">Completed &lt; 1 Year Ago</option>
        </select>
      </div>
      <div className="grid-container">
        <div className="list-container">
          <h1>Sites</h1>
          <ul id="site-list">
            {/* Sites will be dynamically inserted here */}
          </ul>
        </div>
        <div className="details-container">
          <div className="box" id="box1">
            <div className="info-area" id="site-info" />
          </div>
          <div className="box">
            <div className="carousel">
              <div className="carousel-inner">
                <img src={sampleimage1} alt="Image 1" />
                <img src={sampleimage2} alt="Image 2" />
                <img src={"/DJI_0336.JPG"} alt="Image 3" />
              </div>
              <button
                className="carousel-button left"
                onClick={() => this.moveCarousel(-1)}
              >
                ❮
              </button>
              <button
                className="carousel-button right"
                onClick={() => this.moveCarousel(1)}
              >
                ❯
              </button>
            </div>
          </div>
          <div className="box" id="box3">
            <div className="info-area" id="defect-info" />
          </div>
          <div className="box" id="box4">
            <div className="info-area" id="inventory-info" />
          </div>
          <div className="box" id="box5">
            {/* 3D object will be rendered here */}
          </div>
          <div className="box" id="box6">
            <div className="info-area" id="tower-measurement" />
          </div>
        </div>
      </div>
    </div>
  )
}
